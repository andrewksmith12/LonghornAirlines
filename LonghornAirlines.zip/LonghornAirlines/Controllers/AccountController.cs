﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using LonghornAirlines.DAL;
using LonghornAirlines.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace LonghornAirlines.Controllers
{
 
    public class AccountController : Controller
    {
        private SignInManager<AppUser> _signInManager;
        private UserManager<AppUser> _userManager;
        private PasswordValidator<AppUser> _passwordValidator;
        private AppDbContext _db;

        public AccountController(AppDbContext context, UserManager<AppUser> userManager, SignInManager<AppUser> signIn)
        {
            _db = context;
            _userManager = userManager;
            _signInManager = signIn;
            //user manager only has one password validator
            _passwordValidator = (PasswordValidator<AppUser>)userManager.PasswordValidators.FirstOrDefault();
        }

        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }

        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(RegisterViewModel model, Int32? TicketID)
        {
            if (ModelState.IsValid)
            {
                AppUser user = new AppUser
                {
                    //TODO: Add the rest of the custom user fields here
                    UserName = model.Email,
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Birthday = model.Birthday,
                    PhoneNumber = model.PhoneNumber,
                    ZIP = model.ZIP,
                    State = model.State,
                    Street = model.Street,
                    City = model.City,
                    AdvantageNumber = Utilities.GenerateAccountNumber.GetFFNum(_db),
                    UserID = Convert.ToInt32(model.AdvantageNumber),
                    Mileage = 0
                };

                IdentityResult result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    //TODO: Add user to desired role. This example adds the user to the customer role
                    await _userManager.AddToRoleAsync(user, "Customer");

                    if (TicketID.HasValue)
                    {
                        return RedirectToAction("Edit", "Tickets", new
                        {
                            id = TicketID.Value,
                            CustomerID = user.UserID
                        });
                    }
                    else
                    {
                        Microsoft.AspNetCore.Identity.SignInResult result2 = await _signInManager.PasswordSignInAsync(model.Email, model.Password, false, lockoutOnFailure: false);
                        return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    foreach (IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            return View(model);
        }



        // GET: /Account/RegisterEmployee
        [Authorize(Roles = "Manager")]
        public ActionResult RegisterEmployee()
        {
            return View();
        }

        // POST: /Account/RegisterEmployee
        [HttpPost]
        [Authorize(Roles = "Manager")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> RegisterEmployee(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                AppUser user = new AppUser
                {
                    //TODO: Add the rest of the custom user fields here
                    UserName = model.Email,
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Birthday = model.Birthday,
                    PhoneNumber = model.PhoneNumber,
                    ZIP = model.ZIP,
                    State = model.State,
                    Street = model.Street,
                    City = model.City,
                    UserID = Convert.ToInt32(model.AdvantageNumber),
                    SSN = model.SSN
                };

                IdentityResult result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    //TODO: Add user to desired role. This example adds the user to the customer role
                    await _userManager.AddToRoleAsync(user, "Employee");
                    await _userManager.AddToRoleAsync(user, model.Role);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    foreach (IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            return View(model);
        }




        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            if (User.Identity.IsAuthenticated) //user has been redirected here from a page they're not authorized to see
            {
                return View("Error", new string[] { "Access Denied" });
            }
            _signInManager.SignOutAsync(); //this removes any old cookies hanging around
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // This doesn't count login failures towards account lockout
            // To enable password failures to trigger account lockout, change to shouldLockout: true
            Microsoft.AspNetCore.Identity.SignInResult result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, lockoutOnFailure: false);
            if (result.Succeeded)
            {
                return Redirect(returnUrl ?? "/");
            }
            else
            {
                ModelState.AddModelError("", "Invalid login attempt.");
                return View(model);
            }
        }

        //GET: Account/Index
        [Authorize]
        public ActionResult Index()
        {
            IndexViewModel ivm = new IndexViewModel();

            //get user info
            String id = User.Identity.Name;
            AppUser user = _db.Users.FirstOrDefault(u => u.UserName == id);

            //populate the view model
            ivm.Email = user.Email;
            ivm.HasPassword = true;
            ivm.UserID = user.Id;
            ivm.UserName = user.UserName;

            //send data to the view
            return View(ivm);
        }



        //Logic for change password
        // GET: /Account/ChangePassword
        [Authorize]
        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Account/ChangePassword
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            AppUser userLoggedIn = await _userManager.FindByNameAsync(User.Identity.Name);
            var result = await _userManager.ChangePasswordAsync(userLoggedIn, model.OldPassword, model.NewPassword);
            if (result.Succeeded)
            {
                await _signInManager.SignInAsync(userLoggedIn, isPersistent: false); 
                return RedirectToAction("Index", "Home");
            }
            AddErrors(result);
            return View(model);
        }

        //GET:/Account/AccessDenied
        public ActionResult AccessDenied(String ReturnURL)
        {
            return View("Error", new string[] { "Access is denied" });
        }

        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
           

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
        }

        public IActionResult ViewName()
        {
            return View();
        }
        [Authorize(Roles = "Manager,Agent")]
        public IActionResult UserList()
        {
            var PersonList = _db.Users.ToList().Select(p => new EditViewModel1()
            {
                IDNUM = p.UserID,
                FirstName = p.FirstName,
                LastName = p.LastName,
                MI = p.MI,
                Birthday = p.Birthday,
                AdvantageNumber = p.AdvantageNumber,
                Street = p.Street,
                City = p.City,
                State = p.State,
                ZIP = p.ZIP,
                Email = p.Email,
                PhoneNumber = p.PhoneNumber
            });
            return View(PersonList);
        }
        [Authorize]
        [HttpGet]
        public IActionResult EditUser(int id)
        {
            if (id != null && User.IsInRole("Employee"))
            {
                AppUser user = _db.Users.FirstOrDefault(f => f.UserID == id);
                return View(user);
            }
            else
            {
                var user = _userManager.FindByEmailAsync(User.Identity.Name);
                AppUser appUser = user.Result;
                return View(appUser);
            }
        }
        [Authorize]
        [HttpPost]
        public ActionResult EditUser([Bind("FirstName,LastName,MI,Birthday,Street,City,State,ZIP,PhoneNumber")] AppUser user, int UserID)
        {
            // Get the userprofile
            AppUser dbUser = _db.Users.FirstOrDefault(u => u.UserID == UserID);
            dbUser.FirstName = user.FirstName;
            dbUser.LastName = user.LastName;
            dbUser.MI = user.MI;
            dbUser.Birthday = user.Birthday;
            dbUser.PhoneNumber = user.PhoneNumber;
            dbUser.Street = user.Street;
            dbUser.City = user.City;
            dbUser.State = user.State;
            dbUser.ZIP = user.ZIP;
            if (ModelState.IsValid)
            {
                _db.Entry(dbUser).State = EntityState.Modified;
                _db.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return (View());
            }

           

        }
    }
}